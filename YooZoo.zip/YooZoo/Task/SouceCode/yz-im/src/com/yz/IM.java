package com.yz;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class IM {

	// Store all user information
	private HashMap<String, User> userMap = new HashMap<>();

	// Store the messages sent by each user
	private HashMap<String, List<Message>> sentMap = new HashMap<>();

	// Store the messages received by each user
	private HashMap<String, List<Message>> receivedMap = new HashMap<>();

	// Temporary sending user
	private String fromUser = null;

	// Temporary sending content
	private String msg = "";

	// Use for forward api
	private String previousUser = "";

	// Current Login user
	private String currentLoginUser = null;

	// Define auxiliary class, also easy to expand later, for example: class
	// "Message" can give attribute time, then we can catch latest message
	class User {
		private String uid;// user login ID

		public User() {
		};

		public User(String id) {
			this.uid = id;
		}

		public String getUid() {
			return uid;
		}

		public void setUid(String uid) {
			this.uid = uid;
		}
	}

	class Message {
		private String msg;// message content

		public Message() {
		}

		public Message(String msg) {
			this.msg = msg;
		}

		public String getMsg() {
			return msg;
		}

		public void setMsg(String msg) {
			this.msg = msg;
		}
	}

	// ---------------------- Define 6
	// api(login/send/read/reply/forward/broadcast) -----------------

	/**
	 * 
	 * @param uid
	 * @see create a user account if not exist.
	 * @return
	 */
	public String login(String uid) {
		StringBuilder res = new StringBuilder();// result, StringBuilder is more
												// efficient than String
		if (!userMap.containsKey(uid)) {// If user not exist, then create it.
			User u = new User(uid);
			userMap.put(uid, u);
		} else {// Check whether there are unread messages
			if (!receivedMap.isEmpty() && receivedMap.containsKey(uid) && receivedMap.get(uid).size() > 0) {// Map
																											// not
																											// empty
																											// and
																											// has
																											// content
				int count = receivedMap.get(uid).size();
				res.append(uid).append(" logged in");
				res.append(", ").append(count).append(" new messages.");// sum
																		// of
																		// unread
																		// messages
				currentLoginUser = uid;
				return res.toString();
			}
		}
		currentLoginUser = uid;// update current user
		res.append(uid).append(" logged in.");

		return res.toString();
	}

	/**
	 * 
	 * @param uid
	 * @param msg
	 * @see send a message to another user in the system.
	 * @return
	 */
	public String send(String uid, String msg) {
		if (!userMap.containsKey(currentLoginUser)) {// Only registered users
														// can send messages.
			return "error: please login first.";
		}
		if (!userMap.containsKey(uid)) {// If the sending user does not exist,
										// the message cannot be sent either.
			return "error, User does not exist.";
		}
		if (uid.equals(currentLoginUser)) { // You can't send messages to
											// yourself.
			return "error, Illegal operation.";
		}
		Message message = new Message(msg);
		message.setMsg(msg);
		if (sentMap.get(currentLoginUser) != null && sentMap.get(currentLoginUser).size() != 0) { // exist
																									// sent
																									// message
			sentMap.get(currentLoginUser).add(message);
		} else {// first time to send
			List<Message> listSent = new ArrayList<>();
			listSent.add(message);
			sentMap.put(currentLoginUser, listSent);
		}
		if (receivedMap.get(uid) != null && receivedMap.get(uid).size() != 0) { // save
																				// as
																				// sentMap
			receivedMap.get(uid).add(message);
		} else {
			List<Message> listReceived = new ArrayList<>();
			listReceived.add(message);
			receivedMap.put(uid, listReceived);
		}
		return "message sent.";
	}

	/**
	 * @see read a new message to this user.
	 * @return
	 */
	public String read() {
		if (null == currentLoginUser) {// need login first
			return "error, Illegal operation.";
		}
		if (receivedMap.containsKey(currentLoginUser) && receivedMap.get(currentLoginUser).size() > 0) {// Received
																										// messages,
																										// assuming
																										// that
																										// each
																										// message
																										// is
																										// unique,
																										// check
																										// message
																										// from
																										// "sentMap".
			// Take one message from current user.
			Message ms = receivedMap.get(currentLoginUser).get(0);
			msg = ms.getMsg();// Update message.
			receivedMap.get(currentLoginUser).remove(0);// Remove read message.
			// Which user sent this message.
			for (String key : sentMap.keySet()) {
				for (Message m : sentMap.get(key)) {
					if (m.getMsg().equals(msg)) {// Find the senter.
						fromUser = key;
						break;
					}
				}
			}
			StringBuilder sb = new StringBuilder();
			if (msg.indexOf(":") != -1) {// special forward handle
				sb.append("from ").append(msg);
			} else {
				sb.append("from ").append(fromUser).append(":").append(msg);
			}
			previousUser = fromUser;
			return sb.toString();
		}
		fromUser = null;
		return "No new message";// No message receive.
	}

	/**
	 * 
	 * @param msg
	 * @see reply to the current read message.
	 * @return
	 */
	public String reply(String msg) {
		if (null == currentLoginUser) {// need login first
			return "error, Illegal operation.";
		}
		if (null == fromUser) {// read first, then can reply
			return "error, Illegal operation.";
		}
		Message message = new Message(msg);
		message.setMsg(msg);
		// update sentMap and receivedMap
		if (sentMap.get(currentLoginUser) != null && sentMap.get(currentLoginUser).size() != 0) {
			sentMap.get(currentLoginUser).add(message);
		} else {
			List<Message> listSent = new ArrayList<>();
			listSent.add(message);
			sentMap.put(currentLoginUser, listSent);
		}
		if (receivedMap.get(fromUser) != null && receivedMap.get(fromUser).size() != 0) {
			receivedMap.get(fromUser).add(message);
		} else {
			List<Message> listReceived = new ArrayList<>();
			listReceived.add(message);
			receivedMap.put(fromUser, listReceived);
		}
		StringBuilder sb = new StringBuilder();
		sb.append("message sent to ").append(fromUser);

		return sb.toString();
	}

	/**
	 * 
	 * @param uid
	 * @see Forward the current read message to another user.
	 * @return
	 */
	public String forward(String uid) {
		if (null == currentLoginUser) {
			return "error, Illegal operation.";
		}
		if (null == fromUser) {// read first, then can forward
			return "error, Illegal operation.";
		}
		if (currentLoginUser.equals(uid)) {
			return "error, Illegal operation.";// You can't forward messages to
												// yourself.
		}
		StringBuilder sb = new StringBuilder();
		sb.append(previousUser).append(",").append(currentLoginUser).append(":").append(this.msg);
		Message message = new Message(sb.toString());
		message.setMsg(sb.toString());
		// Update sentMap and receivedMap
		if (sentMap.get(currentLoginUser) != null && sentMap.get(currentLoginUser).size() != 0) {
			sentMap.get(currentLoginUser).add(message);
		} else {
			List<Message> listSent = new ArrayList<>();
			listSent.add(message);
			sentMap.put(currentLoginUser, listSent);
		}
		if (receivedMap.get(fromUser) != null && receivedMap.get(fromUser).size() != 0) {
			receivedMap.get(fromUser).add(message);
		} else {
			List<Message> listReceived = new ArrayList<>();
			listReceived.add(message);
			receivedMap.put(fromUser, listReceived);
		}
		StringBuilder str = new StringBuilder();
		str.append("message forwarded to ").append(uid);
		previousUser = "";
		return str.toString();
	}

	/**
	 * 
	 * @param msg
	 * @see Send a broadcast message to all users in the system.
	 */
	public void broadcast(String msg) {
		if (null == currentLoginUser) {// Has current login user.
			return;
		}
		Message message = new Message(msg);
		message.setMsg(msg);
		if (sentMap.get(currentLoginUser) != null && sentMap.get(currentLoginUser).size() != 0) {
			sentMap.get(currentLoginUser).add(message);
		} else {
			List<Message> listSent = new ArrayList<>();
			listSent.add(message);
			sentMap.put(currentLoginUser, listSent);
		}
		for (String userID : userMap.keySet()) {
			if (receivedMap.get(userID) != null && receivedMap.get(userID).size() != 0) {
				receivedMap.get(userID).add(message);
			} else {
				List<Message> listReceived = new ArrayList<>();
				listReceived.add(message);
				receivedMap.put(userID, listReceived);
			}
		}
	}

	public static void main(String[] args) {
		IM im = new IM();
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		StringBuilder sb = new StringBuilder();
		sb.append("please use ").append('"').append("login").append('"').append(" ").append('"').append("send")
				.append('"').append(" ");
		sb.append('"').append("read").append('"').append(" ").append('"').append("reply").append('"').append(" ");
		sb.append('"').append("forward").append('"').append(" ").append('"').append("broadcast").append('"')
				.append(" commands to test");
		System.out.println(sb.toString());
		System.out.println(
				"For commands with parameters, please separate them with spaces and use double quotation marks for message.");
		while (true) {
			String s = scanner.nextLine();
			if (s.contains("login")) {
				if (s.indexOf(" ") > 0) {
					String param = s.substring(s.indexOf(" ") + 1, s.length());
					System.out.println(im.login(param));
				} else {
					System.out.println("Illegal Param.");
				}
			} else if (s.contains("send")) {
				if (s.indexOf(" ") > 0) {
					String param1 = s.substring(s.indexOf(" ") + 1, s.indexOf('"') - 1);
					String param2 = s.substring(s.indexOf('"'), s.length());
					System.out.println(im.send(param1, param2));
				} else {
					System.out.println("Illegal Params.");
				}
			} else if (s.contains("read") && s.indexOf('"') == -1) {
				System.out.println(im.read());
			} else if (s.contains("reply")) {
				if (s.indexOf(" ") > 0) {
					String param = s.substring(s.indexOf('"'), s.length());
					System.out.println(im.reply(param));
				}
			} else if (s.contains("forward")) {
				if (s.indexOf(" ") > 0) {
					String param = s.substring(s.indexOf(" ") + 1, s.length());
					System.out.println(im.forward(param));
				} else {
					System.out.println("Illegal Param.");
				}
			} else if (s.contains("broadcast")) {
				if (s.indexOf(" ") > 0) {
					String param = s.substring(s.indexOf('"'), s.length());
					im.broadcast(param);
				} else {
					System.out.println("Illegal Param.");
				}
			} else if (s.contains("exit")) {
				System.exit(0);
			} else {
				System.out.println("There is an error in the command, try again...");
			}
		}
	}

}
